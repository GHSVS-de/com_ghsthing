<?php
namespace GHSVS\Component\GhsThing\Administrator\Controller;

\defined('_JEXEC') or die;

use Joomla\CMS\MVC\Controller\FormController;
use Joomla\CMS\Versioning\VersionableControllerTrait;

class GhsthingController extends FormController
{
	use VersionableControllerTrait;

}
