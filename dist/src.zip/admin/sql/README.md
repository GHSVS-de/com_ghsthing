https://www.techfry.com/joomla/sql-queries-during-component-install-uninstall-and-update
