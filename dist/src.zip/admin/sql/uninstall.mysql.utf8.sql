DROP TABLE IF EXISTS `#__ghsthing`;
DROP TABLE IF EXISTS `#__ghsthing_frontpage`;
