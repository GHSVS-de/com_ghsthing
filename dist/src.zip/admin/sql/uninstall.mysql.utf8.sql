DROP TABLE IF EXISTS `#__ghsthing`;
