<?php
namespace GHSVS\Component\GhsThing\Administrator\Controller;

\defined('_JEXEC') or die;

use Joomla\CMS\MVC\Controller\FormController;

class GhsthingController extends FormController
{

}
